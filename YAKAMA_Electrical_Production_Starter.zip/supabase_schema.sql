-- YAKAMA Electrical Services: Supabase schema
-- Run in Supabase Dashboard > SQL Editor.
-- Public visitors may INSERT booking/application requests only.
-- Only authenticated users with app_metadata.role = 'admin' can read/manage them.
-- Never place service_role/secret keys in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.booking_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null check (char_length(name) between 1 and 120),
  phone text not null check (char_length(phone) between 10 and 20),
  area text not null check (char_length(area) between 1 and 200),
  service text not null check (char_length(service) between 1 and 160),
  preferred_date date,
  property_type text not null default 'House',
  details text,
  status text not null default 'new' check (status in ('new','contacted','scheduled','completed','cancelled'))
);

create table if not exists public.technician_applications (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null check (char_length(name) between 1 and 120),
  phone text not null check (char_length(phone) between 10 and 20),
  area text not null check (char_length(area) between 1 and 200),
  experience text not null default '0–1 year',
  languages text not null default 'Assamese, Hindi',
  skills text,
  status text not null default 'pending' check (status in ('pending','approved','rejected'))
);

create table if not exists public.technicians (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  area text not null,
  services text[] not null default '{}',
  experience text,
  languages text[] not null default '{}',
  phone text not null,
  approved boolean not null default false,
  available boolean not null default true
);

alter table public.booking_requests enable row level security;
alter table public.technician_applications enable row level security;
alter table public.technicians enable row level security;

-- Visitors can create requests but cannot read other people's data.
drop policy if exists "public can submit booking requests" on public.booking_requests;
create policy "public can submit booking requests"
on public.booking_requests for insert to anon, authenticated
with check (
  char_length(name) between 1 and 120
  and char_length(phone) between 10 and 20
  and char_length(area) between 1 and 200
  and char_length(service) between 1 and 160
);

drop policy if exists "admins manage booking requests" on public.booking_requests;
create policy "admins manage booking requests"
on public.booking_requests for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "public can apply as technician" on public.technician_applications;
create policy "public can apply as technician"
on public.technician_applications for insert to anon, authenticated
with check (
  char_length(name) between 1 and 120
  and char_length(phone) between 10 and 20
  and char_length(area) between 1 and 200
);

drop policy if exists "admins manage technician applications" on public.technician_applications;
create policy "admins manage technician applications"
on public.technician_applications for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "public can view approved technicians" on public.technicians;
create policy "public can view approved technicians"
on public.technicians for select to anon, authenticated
using (approved = true and available = true);

drop policy if exists "admins manage technicians" on public.technicians;
create policy "admins manage technicians"
on public.technicians for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

grant usage on schema public to anon, authenticated;
grant insert on public.booking_requests to anon, authenticated;
grant insert on public.technician_applications to anon, authenticated;
grant select on public.technicians to anon, authenticated;
grant select, update, delete on public.booking_requests to authenticated;
grant select, update, delete on public.technician_applications to authenticated;
grant insert, update, delete, select on public.technicians to authenticated;

-- IMPORTANT:
-- 1) In Supabase Auth, create an admin user.
-- 2) Set that user's app_metadata role to "admin" using a trusted server/admin workflow.
-- Do NOT let a normal user set their own app_metadata role.
-- The SQL Editor is an appropriate place to review requests during initial MVP setup.
